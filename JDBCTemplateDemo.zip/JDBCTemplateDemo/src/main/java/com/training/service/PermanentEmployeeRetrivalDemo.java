package com.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class PermanentEmployeeRetrivalDemo {
	
	
	public static void main(String arg[]){
		
		
		//PermanentEmployeeService service =  new PermanentEmployeeService();
		
		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				 
		PermanentEmployeeService service =  context.getBean("permanentEmployeeService",PermanentEmployeeService.class);
		
		
		//retrieving all employees
		
		service.getAllPermanentEmployees();
		
		System.out.println("----------------------------------");
		
		
		//service.getPermanentEmployeeByEmployeeId(1002);
		
		
		
		
	}

}
