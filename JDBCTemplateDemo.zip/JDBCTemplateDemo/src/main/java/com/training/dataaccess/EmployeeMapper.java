package com.training.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.model.PermanentEmployee;

public class EmployeeMapper implements RowMapper<PermanentEmployee>{

	public PermanentEmployee mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		PermanentEmployee pe =  new PermanentEmployee();
		
		pe.setEmployeeId(rs.getInt("id"));
		
		pe.setName(rs.getString("name"));
		
		pe.setDesignation(rs.getString("design"));
		
		pe.setBasicSalary(rs.getFloat("basic"));
		
		
		return pe;
	}

}
