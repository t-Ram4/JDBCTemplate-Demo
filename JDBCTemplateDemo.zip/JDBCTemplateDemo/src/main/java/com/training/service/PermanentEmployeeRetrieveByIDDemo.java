package com.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PermanentEmployeeRetrieveByIDDemo {
	
	public static void main(String arg[]) {
	
	// loading the definitions from the given XML file
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
					 
			PermanentEmployeeService service =  context.getBean("permanentEmployeeService",PermanentEmployeeService.class);
			
			
			
			System.out.println("----------------------------------");
			
			
			service.getPermanentEmployeeByEmployeeId(5000);
	}
}
