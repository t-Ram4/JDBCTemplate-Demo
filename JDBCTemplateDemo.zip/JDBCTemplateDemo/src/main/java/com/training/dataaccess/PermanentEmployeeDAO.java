package com.training.dataaccess;

import java.util.List;

import com.training.model.PermanentEmployee;

public interface PermanentEmployeeDAO {
	
	public List<PermanentEmployee> getAllPermanentEmployees();
	
	public PermanentEmployee getPermanentEmployeeByEmployeeId(int employeeId);
	
	public void deletePermanentEmployee(int employeeId);
	
	public boolean addPermanentEmployee(PermanentEmployee permanentEmployee);
	
	public void updatePermanentEmployee(PermanentEmployee permanentEmployee);
	
	

}
